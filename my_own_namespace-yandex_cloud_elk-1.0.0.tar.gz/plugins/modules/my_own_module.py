#!/usr/bin/python

# Copyright: (c) 2025, lamer lamer <lamer@example.com>
# GNU General Public License v3.0+
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import os
from ansible.module_utils.basic import AnsibleModule

DOCUMENTATION = r'''
---
module: my_own_module

short_description: Create a file with specified content

version_added: "1.0.0"

description: >
    This module creates a text file at a given path on the remote host with the specified content.
    If the file already exists with the same content, nothing is changed.

options:
    path:
        description:
            - Path to the file to be created.
        required: true
        type: str
    content:
        description:
            - Content to be written to the file.
        required: true
        type: str

author:
    - lamer lamer (@yourGitHubHandle)
'''

EXAMPLES = r'''
- name: Create a file with custom content
  my_own_namespace.yandex_cloud_elk.my_own_module:
    path: /tmp/hello.txt
    content: "Hello, Ansible!"
'''

RETURN = r'''
path:
    description: The path where the file was created or verified.
    type: str
    returned: always
    sample: "/tmp/hello.txt"
changed:
    description: Whether the file was changed.
    type: bool
    returned: always
    sample: true
message:
    description: Status message.
    type: str
    returned: always
    sample: "File created"
'''


def run_module():
    module_args = dict(
        path=dict(type='str', required=True),
        content=dict(type='str', required=True)
    )

    result = dict(
        changed=False,
        path='',
        message=''
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    content = module.params['content']
    result['path'] = path

    if module.check_mode:
        if not os.path.exists(path):
            result['changed'] = True
        else:
            with open(path, 'r') as f:
                existing = f.read()
            if existing != content:
                result['changed'] = True
        module.exit_json(**result)

    try:
        changed = True
        if os.path.exists(path):
            with open(path, 'r') as f:
                existing = f.read()
            if existing == content:
                changed = False

        if changed:
            with open(path, 'w') as f:
                f.write(content)

        result['changed'] = changed
        result['message'] = "File created or updated" if changed else "No changes made"
    except Exception as e:
        module.fail_json(msg=str(e), **result)

    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
