# yandex_cloud_elk collection

Contains:
- module: my_own_module (creates/updates a text file)
- role: file_write (wraps module with defaults)
- playbook: site.yml (demo)

## Role defaults
- path: target file path (default: /tmp/hello_from_role.txt)
- content: file content (default: "Hello from role!")

## Example
ansible-playbook site.yml
